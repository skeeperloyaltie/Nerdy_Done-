import sys

# A: Sets and relations

def succ_map(e):
  d = {}
  for (x,y) in e:
    d[x] = d.get(x,[]) + [y]
  return d

def reach_iter(e,s):
  d = {}
  for x in s:
    d[x] = set()
  for (x,y) in e:
    d[x].add(y)
  return d

def reach_inc_chain(e,s):
  d = {}
  for x in s:
    d[x] = set()
  for (x,y) in e:
    d[x].add(y)
  return d

def reach_inc_direct(e,s):
  d = {}
  for x in s:
    d[x] = set()
  for (x,y) in e:
    d[x].add(y)
  return d

def reach_read():
  filename = sys.argv[1] if len(sys.argv) > 1 else "reach.in.1000"
  with open(filename) as infile: 
    data= infile.read().replace('}\n{','},{').replace('[','(').replace(']',')')
  e,s = eval(data)
  return e,s

def reach_test():
  e,s = reach_read()
  vertices = {x for (x,_) in e} | {y for (_,y) in e}
  print(len(e), len(s), len(vertices))

  rs = reach_iter(e,s)
  print(rs, len(rs))

  e2 = succ_map(e)

  rs2 = reach_inc_chain(e2,s)
  print(rs2 == rs)

  rs3 = reach_inc_direct(e2,s)
  print(rs3 == rs)

reach_test()
