# [] Language: Python3 
import random
import sys
import networkx as nx
import matplotlib.pyplot as plt
import os
os.environ["PATH"] += os.pathsep + 'joaompinto.vscode-graphviz'


######
# Definitions
# Python / Algorithms, directed graphs
# Task: Implement a (directed) graph data structure, as well as some
# searching algorithms to perform a state-space search on the graph.
# Before you choose which data structure to use to represent the graph
# (i.e., adjacency list, adjacency matrix, edge list, etc.), read through the
# whole assignment first, to determine which would be most suitable.

class Graph:
    """
    Graph class.
    """

    def __init__(self):
        """
        Initialize a graph.
        """
        self.vertices = {}
        self.size = 0

    def add_vertex(self, key):
        """
        Add a vertex to the graph.
        """
        self.size += 1
        vertex = Vertex(key)
        self.vertices[key] = vertex
        return vertex

    def add_edge(self, vertex1, vertex2, weight=0):
        """
        Add an edge to the graph.
        """
        if vertex1 not in self.vertices:
            self.add_vertex(vertex1)
        if vertex2 not in self.vertices:
            self.add_vertex(vertex2)
        self.vertices[vertex1].add_connection(self.vertices[vertex2], weight)

    def get_vertex(self, key):
        """
        Get a vertex.
        """
        return self.vertices[key]

    def get_vertices(self):
        """
        Get all vertices.
        """
        return self.vertices.values()

    def __contains__(self, key):
        """
        Check if a vertex is in the graph.
        """
        return key in self.vertices

    def get_num_edges(self):
        """
        Get the number of edges.
        """
        num_edges = 0
        for vertex in self.vertices.values():
            num_edges += vertex.get_num_connections()
        return num_edges / 2
    
    def bfs(self, s, t):
        visited = set()
        queue = []
        queue.append(s)
        while queue:
            s = queue.pop(0)
            for v in s.get_connections():
                if v not in visited:
                    visited.add(v)
                    queue.append(v)
        if t in visited:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        # print the cost of the path
        if t in visited:
            print("Cost of the path: {}".format(t.get_cost()))
        else:
            print("No path from {} to {}".format(s, t))
    
    def dfs(self, s, t):
        visited = set()
        stack = []
        stack.append(s)
        while stack:
            s = stack.pop()
        
        if t in visited:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        if t in visited:
            print("Cost of the path: {}".format(t.get_cost()))
        else:
            print("No path from {} to {}".format(s, t))
    def get_cost(self):
        cost = 0
        for vertex in self.vertices.values():
            cost += vertex.get_cost()
        return cost / 2
    
    def a_star_search(self, s, t):
        """
        A* search.
        """
        visited = set()
        queue = []
        queue.append(s)
        while queue:
            s = queue.pop(0)
            for v in s.get_connections():
                if v not in visited:
                    visited.add(v)
                    queue.append(v)
        if t in visited:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        if t in visited:
            print("Cost of the path: {}".format(t.get_cost()))
        else:
            print("No path from {} to {}".format(s, t))
            
    def ucs_search(self, s, t):
        """
        UCS search.
        """
        visited = set()
        queue = []
        queue.append(s)
        while queue:
            s = queue.pop(0)
            for v in s.get_connections():
                if v not in visited:
                    visited.add(v)
                    queue.append(v)
        if t in visited:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        if t in visited:
            print("Cost of the path: {}".format(t.get_cost()))
        else:
            print("No path from {} to {}".format(s, t))
            
    def id_a_star_search(self, s, t):
        """
        IDA* search.
        """
        visited = set()
        queue = []
        queue.append(s)
        while queue:
            s = queue.pop(0)
            for v in s.get_connections():
                if v not in visited:
                    visited.add(v)
                    queue.append(v)
        if t in visited:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        if t in visited:
            print("Cost of the path: {}".format(t.get_cost()))
        else:
            print("No path from {} to {}".format(s, t))
            
    def bidirectional_search(self, s, t):
        """
        Bidirectional search.
        """
        self.src_queue = list()
        self.dst_queue = list()
        self.src_queue.append(s)
        self.dst_queue.append(t)
        self.src_visited = set()
        self.dst_visited = set()
        self.src_visited.add(s)
        self.dst_visited.add(t)
        self.src_cost = 0
        self.dst_cost = 0
        self.src_cost += s.get_cost()
        self.dst_cost += t.get_cost()
        self.bidirectional_search_helper(s, t)
        if self.src_cost == self.dst_cost:
            print("Path from {} to {}:".format(s, t))
            print(s, end="")
            while t != s:
                s = s.get_connections()
                print(" -> {}".format(s), end="")
            print("")
        else:
            print("No path from {} to {}".format(s, t))
        if self.src_cost == self.dst_cost:
            print("Cost of the path: {}".format(self.src_cost))
        else:
            print("No path from {} to {}".format(s, t))

class Vertex:
    """
    Vertex class.
    """

    def __init__(self, key):
        """
        Initialize a vertex.
        """
        self.key = key
        self.connections = {}
        self.distance = sys.maxsize
        self.visited = False
        self.previous = None

    def add_connection(self, vertex, weight):
        """
        Add a connection to a vertex.
        """
        # assign random weight between 0 & 1 to each edge, weight must be float 
        # therefore random.uniform is used
        # (round(),3) to limit decimal places to 3 by default over 10 d.p. are given 
        weight = (round(random.uniform(0,1),3))
        self.connections[vertex] = weight

    def get_connections(self):
        """
        Get all connections.
        """
        return self.connections.keys()

    def get_num_connections(self):
        """
        Get the number of connections.
        """
        return len(self.connections)

    def get_weight(self, vertex):
        """
        Get the weight of a connection.
        """
        return self.connections[vertex]

    def __str__(self):
        """
        String representation of a vertex.
        """
        return str(self.key) + ' connected to: ' + str([x.key for x in self.connections])
 
def random_graph(n):
    """
    Generate a random graph on n vertices.
    """
    graph = Graph()
    for i in range(n):
        graph.add_vertex(i)
    for i in range(n):
        for j in range(random.randint(1, 4)):
            graph.add_edge(i, random.randint(0, n-1))
    return graph    

def add_edge(graph, vertex1, vertex2, weight=0):
    """
    Add an edge to the graph.
    """
    if vertex1 not in graph.vertices:
        graph.add_vertex(vertex1)
    if vertex2 not in graph.vertices:
        graph.add_vertex(vertex2)
    graph.vertices[vertex1].add_connection(graph.vertices[vertex2], weight)

def random_graph_dot(n):
    """
    Generate a random graph on n vertices.
    """
    graph = Graph()
    for i in range(n):
        graph.add_vertex(i)
    # once in for loop above i = n, we start adding 
    # edges between our generated vertices
    for i in range(n):
        for j in range(random.randint(1, 4)):          # random edge from 1 t0 4
            graph.add_edge(i, random.randint(0, n-1))  # n-1 is used since our first vertex is 0
    return graph


def random_graph_dot_file(n):
    """
    Generate a random graph on n vertices and add weight labels.
    """
    graph = random_graph_dot(n)
    dot_file = open('random_graph.dot', 'w')
    dot_file.write('digraph G {layout = "circo"; overlap = scalexy; sep = "+25,25";\n')
    for vertex in graph.get_vertices():
        for connection in vertex.get_connections():
            dot_file.write('\t' + str(vertex.key) + ' -> ' + str(connection.key) + ' [label="' + str(vertex.get_weight(connection)) + '"]; 1 [style=filled fillcolor=red]; 6 [style=filled fillcolor=green]; 9 [style=filled fillcolor=green]; \n')
    dot_file.write('}')
    dot_file.close()
    os.system('dot -Tpng random_graph.dot -o random_graph.png')
    os.system('open random_graph.png')

def cost(G,p):
    cost = 0
    for i in range(len(p) -1):
        for edge in p[i].out_edge:
            return 



# create a function to add a weight label to the graph
def add_weight(graph, weight):
    """
    Add a weight label to the graph.
    """
    for vertex in graph.get_vertices():
        for connection in vertex.get_connections():
            connection.weight = weight
            
def get_weight(graph, vertex1, vertex2):
    """
    Get the weight of an edge.
    """
    for connection in vertex1:
        if connection == vertex2:
            return connection.weight

def cost_function(graph, path, weight):
    """
    Cost function.
    """
    cost = 0
    while path:
        cost += get_weight(graph, path[0], weight)
    return cost


def print_cost_path(graph, start, target):
    """
    Print the path from the initial vertex to the target vertex, together with
    the associated total cost of the path.
    """
    path = [target]
    while path[0] != start:
        path.insert(0, path[0].previous)
    # print('Path:', [vertex.key for vertex in path])
    print('Cost:', cost_function(graph, path, target))
    
    
def print_line():
    print('-' * 20)


def main():
    n = int(input('Enter the number of vertices: '))
    # graph = Graph()
    #n=3
    graph = Graph()
    # print the number of vertices and edges in the graph
    print('Number of vertices:', n)
    print('Number of edges:', graph.get_num_edges())
    random_graph_dot_file(n)
    
    for i in range(n):
        graph.add_vertex(i)
        break
        # add_weight(graph, random.randint(1, 10))
    for i in range(n):
        for j in range(i + 1, n):
            if random.random() < 2:
                graph.add_edge(i, j)
    
  
    # Breadth-first search
    print_line()    
    print("Breadth-first search")
    start = graph.add_vertex(1)
    target = graph.add_vertex(n)
    print(graph.bfs(start, target))
    print_line()
    print()
    
    # Depth-first search
    print_line()
    print("Depth-first search")
    start = graph.get_vertex(1)
    target = graph.add_vertex(n)
    print(graph.dfs(start, target))
    print_line()
    print()
    
    # A* search
    print_line()
    print("A* search")
    start = graph.add_vertex(1)
    target = graph.add_vertex(n)
    print(graph.a_star_search(start, target))
    print_line()
    print()
    
    # ucs search
    print_line()
    print("ucs search")
    start = graph.add_vertex(1)
    target = graph.add_vertex(n)
    print(graph.ucs_search(start, target))
    print_line()
    print()
    
    # print the graph from the dot file
    random_graph_dot_file(n)
    
    for i in range(n):
        graph.add_vertex(i)
        break
        # add_weight(graph, random.randint(1, 10))
    for i in range(n):
        for j in range(i + 1, n):
            if random.random() < 2:
                graph.add_edge(i, j)
    
if __name__ == '__main__':
    main()



